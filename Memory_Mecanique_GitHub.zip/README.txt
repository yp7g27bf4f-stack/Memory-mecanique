MEMORY MECANIQUE — mise en ligne gratuite

1. Décompresser Memory_Mecanique_GitHub.zip.
2. Dans GitHub, créer un nouveau dépôt PUBLIC.
3. Ajouter le fichier index.html à la racine du dépôt.
4. Ouvrir Settings > Pages.
5. Dans "Build and deployment", choisir la branche main et le dossier / (root).
6. Enregistrer.
7. GitHub publie ensuite le jeu sur une adresse github.io.

GitHub Pages est disponible avec GitHub Free pour les dépôts publics.
